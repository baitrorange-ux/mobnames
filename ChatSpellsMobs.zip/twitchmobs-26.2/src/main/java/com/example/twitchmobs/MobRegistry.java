package com.example.twitchmobs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;

import java.util.*;

/** Maps spellable names ("irongolem") to entity types, using the names from the config. */
public final class MobRegistry implements SpellingEngine.NameIndex {

    /**
     * @param key         the spellable word that triggers this mob (letters a-z only)
     * @param displayName custom announcement name, or "" to use the mob's normal name
     */
    public record MobInfo(EntityType<?> type, Identifier id, String key, String displayName, boolean aquatic) {}

    private final Map<String, MobInfo> byKey = new HashMap<>();
    private final List<String> keysLongestFirst = new ArrayList<>();

    /** Lower-cases, drops any "namespace:" prefix, and keeps only the letters a-z. */
    public static String normalize(String s) {
        if (s == null) return "";
        int colon = s.indexOf(':');
        if (colon >= 0) s = s.substring(colon + 1);
        StringBuilder sb = new StringBuilder(s.length());
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (c >= 'a' && c <= 'z') sb.append(c);
        }
        return sb.toString();
    }

    /**
     * Adds config entries for any mob that doesn't have one yet (never touches existing
     * entries), then builds the name index from the config.
     */
    public static MobRegistry build(MinecraftServer server, TwitchMobsConfig cfg) {
        MobRegistry reg = new MobRegistry();
        ServerLevel level = server.overworld();
        boolean configChanged = false;

        // 1. Find every spawnable mob type, and make sure each has a config entry.
        Map<String, EntityType<?>> found = new TreeMap<>();
        Map<String, Boolean> aquaticById = new HashMap<>();
        for (EntityType<?> type : BuiltInRegistries.ENTITY_TYPE) {
            if (!type.canSummon()) continue;
            Identifier id = BuiltInRegistries.ENTITY_TYPE.getKey(type);

            Entity probe;
            try {
                probe = type.create(level, EntitySpawnReason.EVENT);
            } catch (Throwable t) {
                continue;
            }
            if (!(probe instanceof Mob)) continue;

            MobCategory cat = type.getCategory();
            aquaticById.put(id.toString(), cat == MobCategory.WATER_CREATURE
                    || cat == MobCategory.WATER_AMBIENT
                    || cat == MobCategory.UNDERGROUND_WATER_CREATURE
                    || cat == MobCategory.AXOLOTLS);
            found.put(id.toString(), type);

            if (!cfg.mobs.containsKey(id.toString())) {
                boolean on = !TwitchMobsConfig.DISABLED_BY_DEFAULT.contains(id.toString());
                cfg.mobs.put(id.toString(), new TwitchMobsConfig.MobEntry(on, normalize(id.getPath())));
                configChanged = true;
            }
        }

        // 2. Migrate the old 1.0.0 "blacklist" option, if the file still has one.
        if (cfg.blacklist != null) {
            for (String b : cfg.blacklist) {
                String wanted = normalize(b);
                for (Map.Entry<String, TwitchMobsConfig.MobEntry> e : cfg.mobs.entrySet()) {
                    if (normalize(e.getKey()).equals(wanted)) e.getValue().enabled = false;
                }
            }
            cfg.blacklist = null;
            configChanged = true;
        }

        if (configChanged) {
            cfg.mobs = new TreeMap<>(cfg.mobs); // keep the file sorted
            cfg.save();
        }

        // 3. Build the spellable-name index from the config.
        for (Map.Entry<String, TwitchMobsConfig.MobEntry> e : cfg.mobs.entrySet()) {
            TwitchMobsConfig.MobEntry entry = e.getValue();
            EntityType<?> type = found.get(e.getKey());
            if (!entry.enabled || type == null) continue; // disabled, or mob no longer installed

            Identifier id = BuiltInRegistries.ENTITY_TYPE.getKey(type);
            String display = entry.displayName == null ? "" : entry.displayName.trim();
            for (String raw : entry.names) {
                String key = normalize(raw);
                if (key.isEmpty()) continue;
                if (key.length() < cfg.minNameLength) {
                    TwitchMobs.LOGGER.warn("Ignoring name '{}' for {}: shorter than minNameLength ({})",
                            raw, e.getKey(), cfg.minNameLength);
                    continue;
                }
                MobInfo clash = reg.byKey.get(key);
                if (clash != null) {
                    if (!clash.id().equals(id)) {
                        TwitchMobs.LOGGER.warn("Name '{}' is used by both {} and {}; keeping {}",
                                key, clash.id(), id, clash.id());
                    }
                    continue;
                }
                reg.byKey.put(key, new MobInfo(type, id, key, display, aquaticById.get(e.getKey())));
            }
        }
        reg.keysLongestFirst.addAll(reg.byKey.keySet());
        reg.keysLongestFirst.sort(Comparator.comparingInt(String::length).reversed().thenComparing(Comparator.naturalOrder()));
        return reg;
    }

    public MobInfo get(String key) { return byKey.get(key); }
    public int size() { return byKey.size(); }
    public Collection<String> keys() { return byKey.keySet(); }

    @Override public boolean contains(String name) { return byKey.containsKey(name); }

    @Override public String longestSuffixMatch(String text) {
        for (String k : keysLongestFirst) if (text.endsWith(k)) return k;
        return null;
    }

    @Override public boolean isPrefixOfAny(String prefix) {
        for (String k : keysLongestFirst) if (k.startsWith(prefix)) return true;
        return false;
    }

    @Override public boolean hasLongerNameStartingWith(String prefix) {
        for (String k : keysLongestFirst) if (k.length() > prefix.length() && k.startsWith(prefix)) return true;
        return false;
    }
}

package com.example.twitchmobs;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class TwitchMobs implements ModInitializer {
    public static final String MOD_ID = "twitchmobs";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static volatile MinecraftServer server;
    private static TwitchMobsConfig config;
    private static MobRegistry registry;
    private static volatile SpellingEngine engine;
    private static TwitchChatClient chat;
    private static ScheduledExecutorService scheduler;

    @Override
    public void onInitialize() {
        config = TwitchMobsConfig.load();
        ServerLifecycleEvents.SERVER_STARTED.register(TwitchMobs::start);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> stop());
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                TwitchMobsCommand.register(dispatcher));
    }

    private static void start(MinecraftServer s) {
        server = s;
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "TwitchMobs-Timer");
            t.setDaemon(true);
            return t;
        });
        chat = new TwitchChatClient(TwitchMobs::feedChat);
        reload();
        if (!config.channel.isBlank()) {
            chat.connect(config.channel);
        } else {
            LOGGER.info("No Twitch channel set. Use /twitchmobs connect <channel> or edit config/twitchmobs.json");
        }
    }

    private static void stop() {
        if (chat != null) chat.disconnect();
        if (engine != null) engine.close();
        if (scheduler != null) scheduler.shutdownNow();
        server = null;
    }

    /** Re-reads the config file and rebuilds the mob list. Server thread only. */
    public static synchronized void reload() {
        config = TwitchMobsConfig.load();
        registry = MobRegistry.build(server, config);
        SpellingEngine old = engine;
        engine = new SpellingEngine(registry, TwitchMobs::onSpelled, scheduler,
                config.bufferTimeoutMs, config.graceMs, config.maxBufferLength, config.requireDifferentUsers);
        if (old != null) old.close();
        LOGGER.info("Loaded {} spellable mobs", registry.size());
    }

    public static void feedChat(String user, String message) {
        SpellingEngine e = engine;
        if (e != null) e.onChatMessage(user, message);
    }

    private static void onSpelled(String name, List<String> chatters) {
        MinecraftServer s = server;
        MobRegistry.MobInfo info = registry.get(name);
        if (s == null || info == null) return;
        LOGGER.info("Chat spelled '{}' ({})", name, String.join(", ", chatters));
        s.execute(() -> MobSpawner.spawnOnRandomPlayer(s, info, config, chatters));
    }

    public static void connect(String channel) {
        config.channel = channel.toLowerCase();
        config.save();
        chat.connect(channel);
    }

    public static void disconnect() { chat.disconnect(); }

    public static TwitchMobsConfig config() { return config; }
    public static MobRegistry registry() { return registry; }
    public static TwitchChatClient chat() { return chat; }
}

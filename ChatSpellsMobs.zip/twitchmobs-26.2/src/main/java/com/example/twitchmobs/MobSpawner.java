package com.example.twitchmobs;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class MobSpawner {
    private MobSpawner() {}

    /** Must be called on the server thread. Returns the targeted player, or null if nothing spawned. */
    public static ServerPlayer spawnOnRandomPlayer(MinecraftServer server, MobRegistry.MobInfo info,
                                                   TwitchMobsConfig cfg, List<String> chatters) {
        List<ServerPlayer> candidates = new ArrayList<>();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isAlive() && !p.isSpectator()) candidates.add(p);
        }
        if (candidates.isEmpty()) return null;

        ServerPlayer target = candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
        ServerLevel level = (ServerLevel) target.level();
        BlockPos pos = findSpot(level, target, info, cfg);

        Entity entity = info.type().spawn(level, pos, EntitySpawnReason.EVENT);
        if (entity == null) {
            TwitchMobs.LOGGER.warn("Failed to spawn {}", info.id());
            return null;
        }
        if (cfg.persistent && entity instanceof Mob mob) mob.setPersistenceRequired();

        if (cfg.announce) {
            MutableComponent msg = Component.literal("[Twitch] ").withStyle(ChatFormatting.DARK_PURPLE)
                    .append(Component.literal("Chat spelled ").withStyle(ChatFormatting.GRAY))
                    .append(mobName(info).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD))
                    .append(Component.literal(" on ").withStyle(ChatFormatting.GRAY))
                    .append(target.getName().copy().withStyle(ChatFormatting.AQUA));
            if (!chatters.isEmpty()) {
                String names = String.join(", ", chatters.subList(0, Math.min(5, chatters.size())));
                if (chatters.size() > 5) names += " +" + (chatters.size() - 5);
                msg.append(Component.literal(" (" + names + ")").withStyle(ChatFormatting.DARK_GRAY));
            }
            server.getPlayerList().broadcastSystemMessage(msg, false);
        }
        return target;
    }

    /** The configured display name if there is one, otherwise the mob's normal (translated) name. */
    private static MutableComponent mobName(MobRegistry.MobInfo info) {
        if (!info.displayName().isBlank()) return Component.literal(info.displayName());
        return info.type().getDescription().copy();
    }

    private static BlockPos findSpot(ServerLevel level, ServerPlayer player, MobRegistry.MobInfo info,
                                     TwitchMobsConfig cfg) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        BlockPos base = player.blockPosition();
        int[] dys = {0, 1, -1, 2, -2, 3, -3};
        for (boolean requireGround : new boolean[]{true, false}) {
            for (int attempt = 0; attempt < 24; attempt++) {
                double angle = r.nextDouble() * Math.PI * 2;
                int dist = cfg.spawnRadiusMin + r.nextInt(cfg.spawnRadiusMax - cfg.spawnRadiusMin + 1);
                int x = base.getX() + (int) Math.round(Math.cos(angle) * dist);
                int z = base.getZ() + (int) Math.round(Math.sin(angle) * dist);
                for (int dy : dys) {
                    BlockPos p = new BlockPos(x, base.getY() + dy, z);
                    if (isValid(level, p, info, requireGround)) return p;
                }
            }
        }
        return base; // nowhere nicer: spawn right on the player
    }

    private static boolean isValid(ServerLevel level, BlockPos p, MobRegistry.MobInfo info, boolean requireGround) {
        AABB box = info.type().getDimensions().makeBoundingBox(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
        if (!level.noCollision(box)) return false;
        boolean inWater = level.getFluidState(p).is(FluidTags.WATER);
        if (info.aquatic()) return inWater;
        if (inWater) return false;
        if (!requireGround) return true;
        BlockPos below = p.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }
}

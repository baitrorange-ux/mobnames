package com.example.twitchmobs;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class TwitchMobsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /**
     * Per-mob settings. One entry exists for every spawnable mob type, keyed by its full
     * entity id (e.g. "minecraft:iron_golem"). Missing mobs are added automatically on
     * startup/reload; your edits to existing entries are never overwritten.
     */
    public static class MobEntry {
        /** Set to false to stop chat from spawning this mob. */
        public boolean enabled = true;
        /**
         * Words chat can spell to spawn this mob. Only letters a-z count (case, spaces,
         * underscores and punctuation are ignored), so "Iron Golem" == "irongolem".
         * A mob can have several words, e.g. ["creeper", "boom"].
         */
        public List<String> names = new ArrayList<>();
        /** Name shown in the in-game announcement. Empty = the mob's normal name. */
        public String displayName = "";

        public MobEntry() {}

        public MobEntry(boolean enabled, String defaultName) {
            this.enabled = enabled;
            this.names.add(defaultName);
        }
    }

    /** Twitch channel to read (no #). Leave empty to not auto-connect. */
    public String channel = "";
    /** Letters older than this are forgotten (ms). */
    public int bufferTimeoutMs = 15000;
    /** How long to wait for extra letters when a name could be longer (pig -> piglin). */
    public int graceMs = 2500;
    /** Shortest name (letters only) that can be spelled. Shorter names in "mobs" are ignored. */
    public int minNameLength = 3;
    public int maxBufferLength = 32;
    /** If true, the same chatter can't send two letters in a row. */
    public boolean requireDifferentUsers = false;
    public int spawnRadiusMin = 2;
    public int spawnRadiusMax = 5;
    /** Spawned mobs never despawn. */
    public boolean persistent = false;
    /** Broadcast a chat message in-game when a mob is spawned. */
    public boolean announce = true;

    /** Spellable names and display names for every mob. Edit these freely. */
    public Map<String, MobEntry> mobs = new TreeMap<>();

    /**
     * Legacy option from version 1.0.0. If an old config still has it, those mobs are
     * switched to "enabled": false in "mobs" and this field is removed from the file.
     */
    public List<String> blacklist = null;

    /** Mobs that start out disabled the first time they are added to the config. */
    public static final List<String> DISABLED_BY_DEFAULT = List.of("minecraft:ender_dragon", "minecraft:wither");

    public static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("twitchmobs.json");
    }

    public static TwitchMobsConfig load() {
        Path p = path();
        TwitchMobsConfig cfg = null;
        if (Files.exists(p)) {
            try {
                cfg = GSON.fromJson(Files.readString(p), TwitchMobsConfig.class);
            } catch (Exception e) {
                TwitchMobs.LOGGER.error("Could not read {}, using defaults", p, e);
            }
        }
        if (cfg == null) cfg = new TwitchMobsConfig();
        if (cfg.channel == null) cfg.channel = "";
        if (cfg.mobs == null) cfg.mobs = new TreeMap<>();
        // drop null/broken entries and make sure no field is null
        cfg.mobs.values().removeIf(e -> e == null);
        for (MobEntry e : cfg.mobs.values()) {
            if (e.names == null) e.names = new ArrayList<>();
            if (e.displayName == null) e.displayName = "";
        }
        if (cfg.spawnRadiusMax < cfg.spawnRadiusMin) cfg.spawnRadiusMax = cfg.spawnRadiusMin;
        cfg.save();
        return cfg;
    }

    public void save() {
        try {
            Files.createDirectories(path().getParent());
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException e) {
            TwitchMobs.LOGGER.error("Could not save config", e);
        }
    }
}

package com.example.twitchmobs;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * Collects single-letter chat messages into a rolling buffer and fires when the
 * end of the buffer spells a known name. Has no Minecraft dependencies.
 *
 * Ambiguous names ("pig" vs "piglin", "zombie" vs "zombie_villager") are handled
 * by waiting a short grace period for more letters before firing.
 */
public final class SpellingEngine {

    public interface NameIndex {
        boolean contains(String name);
        /** Longest known name that the text ends with, or null. */
        String longestSuffixMatch(String text);
        /** True if any known name starts with this prefix (including equal). */
        boolean isPrefixOfAny(String prefix);
        /** True if a strictly longer known name starts with this prefix. */
        boolean hasLongerNameStartingWith(String prefix);
    }

    public interface Listener {
        void onSpelled(String name, List<String> chatters);
    }

    // whitespace, Twitch's anti-duplicate tag characters, zero-width characters
    private static final Pattern IGNORED =
            Pattern.compile("[\\s\\x{E0000}-\\x{E007F}\\u200B-\\u200D\\u2060\\uFEFF]");

    private final NameIndex names;
    private final Listener listener;
    private final ScheduledExecutorService scheduler;
    private final int bufferTimeoutMs;
    private final int graceMs;
    private final int maxBufferLength;
    private final boolean requireDifferentUsers;

    private final StringBuilder buffer = new StringBuilder();
    private final ArrayList<String> bufferUsers = new ArrayList<>();
    private long lastLetterAt = 0;
    private String lastUser = "";
    private String pendingPrefix;
    private String pendingName;
    private ScheduledFuture<?> timer;
    private long generation = 0;

    public SpellingEngine(NameIndex names, Listener listener, ScheduledExecutorService scheduler,
                          int bufferTimeoutMs, int graceMs, int maxBufferLength, boolean requireDifferentUsers) {
        this.names = names;
        this.listener = listener;
        this.scheduler = scheduler;
        this.bufferTimeoutMs = bufferTimeoutMs;
        this.graceMs = graceMs;
        this.maxBufferLength = Math.max(8, maxBufferLength);
        this.requireDifferentUsers = requireDifferentUsers;
    }

    /** Feed any chat message; non single-letter messages are ignored. */
    public void onChatMessage(String user, String rawMessage) {
        String m = IGNORED.matcher(rawMessage).replaceAll("");
        if (m.length() != 1) return;
        char c = Character.toLowerCase(m.charAt(0));
        if (c < 'a' || c > 'z') return;
        synchronized (this) {
            handleLetter(user, c);
        }
    }

    public synchronized void close() {
        reset();
    }

    private void handleLetter(String user, char c) {
        long now = System.currentTimeMillis();
        if (lastLetterAt != 0 && now - lastLetterAt > bufferTimeoutMs) {
            if (pendingName != null) fire();
            reset();
        }
        if (requireDifferentUsers && user.equalsIgnoreCase(lastUser)) return;

        if (pendingPrefix != null) {
            String candidate = pendingPrefix + c;
            if (names.isPrefixOfAny(candidate)) {
                append(user, c);
                lastLetterAt = now;
                lastUser = user;
                pendingPrefix = candidate;
                if (names.contains(candidate)) pendingName = candidate;
                if (candidate.equals(pendingName) && !names.hasLongerNameStartingWith(candidate)) {
                    fire();
                } else {
                    arm();
                }
                return;
            }
            // letter doesn't continue a longer name: lock in the shorter one
            fire();
        }

        append(user, c);
        lastLetterAt = now;
        lastUser = user;

        String match = names.longestSuffixMatch(buffer.toString());
        if (match == null) return;
        pendingName = match;
        pendingPrefix = match;
        if (names.hasLongerNameStartingWith(match)) {
            arm();
        } else {
            fire();
        }
    }

    private void append(String user, char c) {
        buffer.append(c);
        bufferUsers.add(user);
        while (buffer.length() > maxBufferLength) {
            buffer.deleteCharAt(0);
            bufferUsers.remove(0);
        }
    }

    private void arm() {
        cancelTimer();
        final long myGen = ++generation;
        timer = scheduler.schedule(() -> {
            synchronized (SpellingEngine.this) {
                if (myGen == generation && pendingName != null) fire();
            }
        }, graceMs, TimeUnit.MILLISECONDS);
    }

    private void cancelTimer() {
        generation++;
        if (timer != null) {
            timer.cancel(false);
            timer = null;
        }
    }

    private void fire() {
        String name = pendingName;
        int extra = pendingPrefix.length() - name.length();
        int end = Math.max(0, bufferUsers.size() - extra);
        int start = Math.max(0, end - name.length());
        List<String> chatters = new ArrayList<>(new LinkedHashSet<>(bufferUsers.subList(start, end)));
        reset();
        listener.onSpelled(name, chatters);
    }

    private void reset() {
        cancelTimer();
        buffer.setLength(0);
        bufferUsers.clear();
        pendingName = null;
        pendingPrefix = null;
    }
}

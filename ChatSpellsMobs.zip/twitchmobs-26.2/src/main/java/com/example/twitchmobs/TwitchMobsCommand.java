package com.example.twitchmobs;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;

import java.util.List;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public final class TwitchMobsCommand {
    private TwitchMobsCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("twitchmobs")
                .requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(literal("connect").then(argument("channel", StringArgumentType.word()).executes(ctx -> {
                    String ch = StringArgumentType.getString(ctx, "channel");
                    TwitchMobs.connect(ch);
                    reply(ctx.getSource(), "Connecting to Twitch chat of #" + ch.toLowerCase() + " (saved to config).");
                    return 1;
                })))
                .then(literal("disconnect").executes(ctx -> {
                    TwitchMobs.disconnect();
                    reply(ctx.getSource(), "Disconnected from Twitch chat.");
                    return 1;
                }))
                .then(literal("status").executes(ctx -> {
                    TwitchChatClient c = TwitchMobs.chat();
                    reply(ctx.getSource(), "Channel: #" + c.channel()
                            + " | connected: " + c.isConnected()
                            + " | joined: " + c.isJoined()
                            + " | spellable mobs: " + TwitchMobs.registry().size());
                    return 1;
                }))
                .then(literal("reload").executes(ctx -> {
                    TwitchMobs.reload();
                    reply(ctx.getSource(), "Config reloaded. Spellable mobs: " + TwitchMobs.registry().size());
                    return 1;
                }))
                .then(literal("spawn").then(argument("mob", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(TwitchMobs.registry().keys(), b))
                        .executes(ctx -> {
                            String key = MobRegistry.normalize(StringArgumentType.getString(ctx, "mob"));
                            MobRegistry.MobInfo info = TwitchMobs.registry().get(key);
                            if (info == null) {
                                reply(ctx.getSource(), "Unknown or disabled mob name: " + key);
                                return 0;
                            }
                            var target = MobSpawner.spawnOnRandomPlayer(ctx.getSource().getServer(), info,
                                    TwitchMobs.config(), List.of("command"));
                            if (target == null) reply(ctx.getSource(), "No eligible player to spawn on.");
                            return target == null ? 0 : 1;
                        })))
                .then(literal("simulate").then(argument("letters", StringArgumentType.word()).executes(ctx -> {
                    String letters = StringArgumentType.getString(ctx, "letters");
                    for (int i = 0; i < letters.length(); i++) {
                        TwitchMobs.feedChat("viewer" + (i % 7 + 1), String.valueOf(letters.charAt(i)));
                    }
                    reply(ctx.getSource(), "Fed " + letters.length() + " letters into the spelling engine.");
                    return 1;
                })))
        );
    }

    private static void reply(CommandSourceStack src, String msg) {
        src.sendSuccess(() -> Component.literal("[TwitchMobs] " + msg), false);
    }
}

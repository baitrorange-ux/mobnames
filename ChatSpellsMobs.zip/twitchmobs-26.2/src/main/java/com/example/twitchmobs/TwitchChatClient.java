package com.example.twitchmobs;

import javax.net.ssl.SSLSocketFactory;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;

/** Anonymous, read-only Twitch IRC client (no OAuth token needed). Auto-reconnects. */
public final class TwitchChatClient {
    private static final String HOST = "irc.chat.twitch.tv";
    private static final int PORT = 6697;

    private final BiConsumer<String, String> handler; // (user, message)
    private final AtomicInteger session = new AtomicInteger();
    private volatile Socket socket;
    private volatile String channel = "";
    private volatile boolean connected;
    private volatile boolean joined;

    public TwitchChatClient(BiConsumer<String, String> handler) {
        this.handler = handler;
    }

    public String channel() { return channel; }
    public boolean isConnected() { return connected; }
    public boolean isJoined() { return joined; }

    public synchronized void connect(String channelName) {
        disconnect();
        this.channel = channelName.trim().toLowerCase(Locale.ROOT).replaceFirst("^#", "");
        final int id = session.incrementAndGet();
        Thread t = new Thread(() -> run(id), "TwitchMobs-IRC");
        t.setDaemon(true);
        t.start();
    }

    public synchronized void disconnect() {
        session.incrementAndGet();
        connected = false;
        joined = false;
        Socket s = socket;
        if (s != null) {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    private void run(int id) {
        int backoff = 2000;
        while (session.get() == id) {
            try (Socket s = SSLSocketFactory.getDefault().createSocket(HOST, PORT)) {
                socket = s;
                s.setSoTimeout(330_000);
                if (session.get() != id) return;
                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
                send(out, "PASS SCHMOOPIIE");
                send(out, "NICK justinfan" + ThreadLocalRandom.current().nextInt(10000, 99999));
                send(out, "JOIN #" + channel);
                connected = true;
                backoff = 2000;
                TwitchMobs.LOGGER.info("Connected to Twitch chat, joining #{}", channel);

                String line;
                while (session.get() == id && (line = in.readLine()) != null) {
                    try {
                        handleLine(line, out);
                    } catch (Exception e) {
                        TwitchMobs.LOGGER.warn("Error handling chat line", e);
                    }
                }
            } catch (IOException e) {
                if (session.get() == id) TwitchMobs.LOGGER.warn("Twitch chat connection error: {}", e.toString());
            }
            if (session.get() == id) {
                connected = false;
                joined = false;
                TwitchMobs.LOGGER.info("Reconnecting to Twitch chat in {} ms", backoff);
                sleepWhileActive(id, backoff);
                backoff = Math.min(backoff * 2, 60_000);
            }
        }
    }

    private void handleLine(String line, BufferedWriter out) throws IOException {
        if (line.startsWith("PING")) {
            send(out, "PONG" + line.substring(4));
            return;
        }
        if (line.contains(" 366 ") || line.contains(" JOIN #")) {
            if (!joined) TwitchMobs.LOGGER.info("Joined #{}", channel);
            joined = true;
        }
        int p = line.indexOf(" PRIVMSG #");
        if (!line.startsWith(":") || p < 0) return;
        int bang = line.indexOf('!');
        if (bang < 1 || bang > p) return;
        int msgStart = line.indexOf(" :", p + 1);
        if (msgStart < 0) return;
        handler.accept(line.substring(1, bang), line.substring(msgStart + 2));
    }

    private static void send(BufferedWriter out, String s) throws IOException {
        out.write(s + "\r\n");
        out.flush();
    }

    private void sleepWhileActive(int id, int ms) {
        long end = System.currentTimeMillis() + ms;
        while (session.get() == id && System.currentTimeMillis() < end) {
            try { Thread.sleep(250); } catch (InterruptedException e) { return; }
        }
    }
}

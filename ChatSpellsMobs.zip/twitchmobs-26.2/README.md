# Twitch Mob Spelling (Fabric 26.2)

Viewers type a mob's name one letter per message (`z`, `o`, `m`, `b`, `i`, `e`).
When the end of the letter stream matches a mob name, that mob spawns near a random player.

## Build
Minecraft 26.x is unobfuscated, so this project uses Mojang's names, the
`net.fabricmc.fabric-loom` plugin, and no mappings line.

Requires JDK 25. The Gradle wrapper is included, so no Gradle install is needed:

    ./gradlew build          # Windows: gradlew.bat build

Jar: `build/libs/twitchmobs-1.0.0+26.2.jar` (not the `-sources` one).
Install with Fabric Loader 0.19.3+ and Fabric API 0.152.x for 26.2.

## Use (op only)
    /twitchmobs connect <channel>
    /twitchmobs disconnect | status | reload
    /twitchmobs spawn <mob>          test spawn
    /twitchmobs simulate <letters>   e.g. creeper

Chat is read anonymously: no OAuth token needed.

## Rules
- Only messages that are exactly one letter (a-z, any case) count.
- Names only use the letters a-z: `iron_golem` is spelled `irongolem` by default (see below to change it).
- Matching is against the END of a rolling buffer, so stray letters don't break it.
- Ambiguous names wait `graceMs` for more letters (`pig` vs `piglin`).
- Every living mob type works (including modded) unless you set it to `"enabled": false`.

## Config (config/twitchmobs.json)
General settings: channel, bufferTimeoutMs (15000), graceMs (2500), minNameLength (3),
maxBufferLength (32), requireDifferentUsers (false), spawnRadiusMin/Max (2/5),
persistent (false), announce (true).

### Changing mob names
Every spawnable mob gets an entry under `mobs`, created automatically the first time
the server starts (mods you add later get their entries added too). Edit the file, then
run `/twitchmobs reload` - no restart needed.

    "mobs": {
      "minecraft:creeper": {
        "enabled": true,
        "names": ["creeper", "boom"],
        "displayName": "Big Boom"
      },
      "minecraft:ender_dragon": {
        "enabled": false,
        "names": ["enderdragon"],
        "displayName": ""
      }
    }

- `names`: every word chat can spell to spawn this mob. Only letters a-z count; case,
  spaces, underscores and punctuation are ignored (`"Iron Golem"` = `irongolem`).
  Put in as many as you like.
- `displayName`: what the in-game announcement calls the mob. Empty = its normal name.
- `enabled`: `false` stops chat from spawning it (ender_dragon and wither start disabled).
- If two mobs share a word, the first one in the file wins and a warning is logged.
- Words shorter than `minNameLength` are ignored.
- Your edits are never overwritten. Upgrading from 1.0.0: the old `blacklist` is
  converted to `"enabled": false` entries automatically.

## Getting the jar without installing anything
Push this folder to a GitHub repo (or upload it via "Add file > Upload files"), open the
Actions tab, run "Build mod jar", and download the `twitchmobs-jar` artifact.
